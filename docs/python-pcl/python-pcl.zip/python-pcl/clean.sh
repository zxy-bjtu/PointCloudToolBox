sudo rm pcl/_pcl*.cpp
sudo rm pcl/_pcl*.pyd
sudo rm pcl/pcl_registration_*.cpp
sudo rm pcl/pcl_registration_*.pyd
sudo rm pcl/pcl_visualization*.cpp
sudo rm pcl/pcl_visualization*.pyd
sudo rm pcl/pcl_grabber*.cpp
sudo rm pcl/pcl_grabber*.pyd
sudo rm -rf build
sudo rm -rf python_pcl.egg-info
pip uninstall python-pcl -y