
0. libfreenect2 install
https://github.com/OpenKinect/libfreenect2

1. pylibfreenect2 install 

1-a. pip install
```cmd
pip install pylibfreenect2
```

1-b. Source Code
```cmd
git clone https://github.com/r9y9/pylibfreenect2.git
python setup.py install
```

Reference :
http://r9y9.github.io/pylibfreenect2/stable/installation.html

2. execute example

* before Kinect2 device connected

python examples.py


