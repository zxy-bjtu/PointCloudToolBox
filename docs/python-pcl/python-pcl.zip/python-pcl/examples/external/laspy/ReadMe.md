
1. Install module
pip install laspy

Use Data : ShizuokaDB las files.
https://pointcloud.pref.shizuoka.jp/

XYZTestData :
https://pointcloud.pref.shizuoka.jp/lasmap/ankendetail?ankenno=28XXX10000075

XYZRGBTestData :
https://pointcloud.pref.shizuoka.jp/lasmap/ankendetail?ankenno=28W0608011101

